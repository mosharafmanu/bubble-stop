# Bubble Stop - Product Data Model

## Product Type

Each drink should be a WooCommerce product.

Examples:

- Mango Mania
- Brown Sugar
- Apple Fruit Tea
- Strawberry Cheesecake Milkshake
- Watermelon Fizz

## Product Categories

Use WooCommerce product categories:

- Milk Blends
- Milkshakes
- Smoothies
- Fizz Mojitos
- Fruit Teas
- Iced Coffee
- Hot Drinks
- Coffee
- Tea

## Product Variation

Only use WooCommerce variations for Size.

### Size Options

- Regular
- Large

Each size can have a different price.

Example:

Mango Mania:
- Regular: £5.50
- Large: £6.50

## Custom Order Options

These should not be WooCommerce variations.

Save them as cart item meta and order item meta.

### Sweetness

- Less
- Normal
- More

### Ice Level

- Less
- Normal
- More

### Free Topping

Examples:

- Original Tapioca
- Jelly
- Mango Bubbles
- Lychee Bubbles
- Strawberry Bubbles

### Extra Topping

Paid add-on.

Example additional cost:

+£0.50

### Extra

Paid add-on.

Examples:

- Whipped Cream
- Cheese Cloud

Example additional cost:

+£0.50

### Booster

Paid add-on.

Examples:

- Sea Moss Gel

Example additional cost:

+£0.50

## Main Rule

Avoid creating too many WooCommerce variations.

Only Size should be a variation.

All other drink customization choices should be stored as custom cart/order metadata.
