# Bubble Stop - Project Overview

## Project Type

Bubble Stop is a custom WooCommerce theme for a bubble tea and coffee shop.

The website is not a traditional eCommerce store. It is a café-style ordering website where customers browse the menu, customize drinks, add them to cart, and complete checkout.

## Main Goal

Create a clean, playful, pastel-branded WooCommerce website that supports:

- Brand storytelling
- Drink menu browsing
- Product category sections
- Custom drink ordering
- Cart and checkout
- Loyalty/rewards promotion
- Community trust building

## Core Customer Journey

Home  
→ Menu  
→ Order Page  
→ Cart  
→ Checkout

## Pages

- Home
- Menu / Shop
- Order / Single Product
- Coffee
- About
- Community
- Rewards
- Cart
- Checkout
- My Account

## Important Note

There should be no separate product information page.

The Order Page should work as the single product page and drink configurator.
