# Bubble Stop - Development Roadmap

## Phase 1: Project Setup

- Create custom WordPress theme
- Add WooCommerce support
- Add theme assets structure
- Add reusable template parts
- Setup CSS/JS build workflow if needed

## Phase 2: Global Layout

- Header
- Navigation
- Account icon
- Cart icon
- Footer
- Responsive layout

## Phase 3: Homepage

Build homepage sections:

- Hero
- Our Journey
- Drinks Selection
- Coffee Promotion
- Rewards Preview
- Testimonials
- Footer

## Phase 4: Menu Page

Build custom WooCommerce shop/menu page:

- Category sections
- Product cards
- Product sliders
- Add/order buttons
- Mobile responsive layout

## Phase 5: Order Page

Build custom single product/order page:

- Product image
- Product name
- Size variations
- Sweetness
- Ice level
- Toppings
- Paid add-ons
- Add to Cart

## Phase 6: Cart and Checkout

- Style WooCommerce cart
- Show custom drink selections
- Style checkout
- Make order data clear for admin/staff

## Phase 7: Static/Content Pages

- Coffee
- About
- Community
- Rewards

## Phase 8: QA

- Desktop testing
- Mobile testing
- WooCommerce cart testing
- Checkout testing
- Variation testing
- Custom add-on pricing testing
- Order admin testing

## Phase 9: Launch Preparation

- Performance check
- Image optimization
- SEO basics
- Security basics
- Final client review
