# Bubble Stop - Order Page Specification

## Purpose

The Order Page is the most important page in the entire Bubble Stop website.

This page serves as both:

1. Product Details Page
2. Drink Customization Page

There is no separate product information page.

The customer should be able to:

- View the drink
- Configure the drink
- Add the drink to cart

from a single page.

## Customer Flow

Homepage  
→ Menu Page  
→ Order Page  
→ Cart  
→ Checkout

## Layout

### Left Column

- Product image
- Featured image from WooCommerce

### Right Column

- Product name
- Size selector
- Sweetness selector
- Ice level selector
- Free topping selector
- Extra topping selector
- Extra selector
- Booster selector
- Add to Cart button

## Size

Type: WooCommerce Product Variation

Required: Yes

Options:

- Regular
- Large

Rules:

- Price updates when variation changes.
- Must be selected before adding to cart.
- Use WooCommerce variations, not custom fields.

## Sweetness

Type: Customer preference

Required: Yes

Options:

- Less
- Normal
- More

Rules:

- No price change.
- Save in cart item data.
- Save in order item meta.

## Ice Level

Type: Customer preference

Required: Yes

Options:

- Less
- Normal
- More

Rules:

- No price change.
- Save in cart item data.
- Save in order item meta.

## Free Topping

Type: Drink customization

Required: No

Client clarification required:

- Single selection?
- Multiple selection?

Rules:

- No additional cost.
- Save in cart item data.
- Save in order item meta.

## Extra Topping

Type: Paid add-on

Required: No

Additional cost:

+£0.50

Rules:

- Add price adjustment.
- Save in cart item data.
- Save in order item meta.

## Extra

Type: Paid add-on

Required: No

Additional cost:

+£0.50

## Booster

Type: Paid add-on

Required: No

Additional cost:

+£0.50

## Add To Cart Requirements

- Validate required selections.
- Add selected variation.
- Add custom options.
- Add paid add-on prices.
- Show selected options in cart.
- Save selected options in order admin.

## Success Criteria

A customer can select drink options, add the configured drink to cart, checkout, and staff can clearly see all selected options in the WooCommerce order.
