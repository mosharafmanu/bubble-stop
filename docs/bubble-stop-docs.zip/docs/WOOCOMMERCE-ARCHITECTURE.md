# Bubble Stop - WooCommerce Architecture

## WooCommerce Role

WooCommerce powers:

- Product management
- Menu items
- Product categories
- Product variations
- Cart
- Checkout
- My Account
- Orders

## Shop Page

The WooCommerce Shop page should be visually presented as the Menu page.

Do not use default WooCommerce grid styling.

The Menu page should display category-based sections.

## Product Categories

- Milk Blends
- Milkshakes
- Smoothies
- Fizz Mojitos
- Fruit Teas
- Iced Coffee
- Hot Drinks
- Coffee
- Tea

## Single Product Page

The WooCommerce single product page should be customized as the Order Page.

No separate product info page is needed.

## Variations

Use variations only for Size:

- Regular
- Large

## Cart Item Meta

Save these custom options with each cart item:

- Sweetness
- Ice Level
- Free Topping
- Extra Topping
- Extra
- Booster

## Pricing Logic

Base price comes from selected size variation.

Additional paid add-ons:

- Extra Topping: +£0.50
- Extra: +£0.50
- Booster: +£0.50

## Cart Display

Cart should show:

- Product name
- Selected size
- Sweetness
- Ice level
- Toppings
- Add-ons
- Final price

## Order Admin Display

WooCommerce order admin must show all selected customizations so staff can prepare the drink correctly.

## Development Notes

Use WooCommerce hooks and template overrides properly.

Avoid hacking WooCommerce core.

Keep logic modular inside `/inc/woocommerce/` if possible.
