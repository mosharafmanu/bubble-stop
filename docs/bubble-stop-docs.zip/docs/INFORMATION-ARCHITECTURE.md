# Bubble Stop - Information Architecture

## Main Navigation

- Menu
- Coffee
- About
- Community
- Rewards

## Utility Navigation

- My Account
- Cart

## Site Structure

Home
├── Menu
│   ├── Milk Blends
│   ├── Milkshakes
│   ├── Smoothies
│   ├── Fizz Mojitos
│   ├── Fruit Teas
│   ├── Iced Coffee
│   ├── Hot Drinks
│   ├── Coffee
│   └── Tea
├── Order Page
├── Coffee
├── About
├── Community
├── Rewards
├── Cart
├── Checkout
└── My Account

## Homepage Sections

- Header
- Hero
- Our Journey
- Drinks Selection
- Coffee Promotion
- Rewards Preview
- Community Testimonials
- Footer

## Menu Page Purpose

The Menu page is the WooCommerce shop page, redesigned as a café menu.

It should show all drink categories with product sliders/cards.

## Order Page Purpose

The Order Page is the single product page.

It must allow the customer to configure and add the drink to cart.
